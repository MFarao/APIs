package com.uade.tpo.demo.controllers.order;

import lombok.Data;

@Data
public class OrderStatusRequest {
    private String status;
}
