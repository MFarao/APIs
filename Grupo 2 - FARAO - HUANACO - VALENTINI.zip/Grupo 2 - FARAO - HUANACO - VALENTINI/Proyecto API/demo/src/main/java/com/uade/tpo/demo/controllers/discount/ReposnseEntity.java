package com.uade.tpo.demo.controllers.discount;

public class ReposnseEntity<T> {

}
