package com.uade.tpo.demo.controllers.product;

import lombok.Data;

@Data
public class ProductNameRequest {
    private String name;
}
