package com.uade.tpo.demo.entity;

public enum Role {
    USER,
    ADMIN,
    BLOQUEADO
}
