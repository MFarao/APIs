package com.uade.tpo.demo.controllers.categories;

import lombok.Data;

@Data
public class CategoryRequest {
    private String description;
}
