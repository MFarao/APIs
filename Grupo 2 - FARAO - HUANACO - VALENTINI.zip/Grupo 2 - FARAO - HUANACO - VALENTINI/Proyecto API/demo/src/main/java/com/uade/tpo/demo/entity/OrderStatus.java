package com.uade.tpo.demo.entity;

public enum OrderStatus {
    PAGO,
    PREPARANDO,
    ENVIADO,
    ENTREGADO
}
